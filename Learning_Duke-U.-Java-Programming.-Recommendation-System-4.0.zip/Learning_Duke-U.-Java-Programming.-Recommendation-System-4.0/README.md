# The capstone project. Recommendation System

## Java Programming: Build a Recommendation System


---

[Java Programming: Build a Recommendation System](https://www.coursera.org/learn/java-programming-recommender)
by Duke University

Course 5 of 5 in the [Java Programming and Software Engineering Fundamentals Specialization](https://www.coursera.org/specializations/java-programming)

